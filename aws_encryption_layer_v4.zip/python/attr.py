import attrs; globals().update(vars(attrs))
