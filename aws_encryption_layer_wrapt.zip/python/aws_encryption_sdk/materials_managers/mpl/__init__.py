# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Modules related to the MPL's materials managers interfaces.

The aws-cryptographic-materials-library MUST be installed to use these modules.
"""
